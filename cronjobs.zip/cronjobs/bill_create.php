<?php 
$host = 'localhost';
$dbname = 'dataljb7_express';
$user = 'dataljb7_express';
$password = 'andy247742';
$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8mb4', $user, $password);
?>
<?php include("message.php");?>
<?php
$qry = "SELECT * FROM `billings` ORDER BY id";
$stmt = $db->query($qry);
while($row_edt = $stmt->fetch(PDO::FETCH_ASSOC)){
    $tenant = $row_edt['tenant'];
    $billname = $row_edt['billname'];
    $title = "$billname Bill is Due.";
    $qry111 = "SELECT * FROM `subscribers` WHERE id = '$tenant'";
    $stmt111 = $db->query($qry111);
    $row_edt111 = $stmt111->fetch(PDO::FETCH_ASSOC);
    $msgorg = $row_edt111['businessname'];
    $user = $row_edt['user'];
    $frequency = $row_edt['frequency'];
    $amount = $row_edt['amount'];
    $invoiceno = $row_edt['id'];
    $billitemcode = $row_edt['billitemcode'];

    if($frequency == "One-Off"){
        $qry1 = "SELECT * FROM residents WHERE tenant = '$tenant' AND id NOT IN 
            (SELECT surname FROM invoices WHERE tenant = '$tenant' AND invoiceno = '$invoiceno') ORDER BY id DESC";
        $stmt1 = $db->query($qry1);
        while($row_edt1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
            $surname = $row_edt1['id'];
            $to = $row_edt1['email'];
            $name = $row_edt1['surname']." ".$row_edt1['othername'];
            $msg .= "Dear $name<br><br>";
            $msg .= "This is to notify you that your invoice for $billname is now due.<br>";
            $msg .= "Amount Due: $amount<br><br>";
            $msg .= "Best Regards";
            send_email($msgorg,$to,$title,$msg);
            $qry2 = "INSERT INTO invoices (`date`,invoiceyear,invoicemonth,invoiceday,surname,invoiceno,billitemcode,amount,`invoicestatus`,tenant,user) 
            VALUES (CURDATE(),'All','All','All','$surname','$invoiceno','$billitemcode','$amount','Not Paid','$tenant','$user')";
            $stmt2 = $db->query($qry2);
        }
    } elseif($frequency == "Yearly"){
        $qry1 = "SELECT * FROM residents WHERE tenant = '$tenant' AND id NOT IN 
            (SELECT surname FROM invoices WHERE tenant = '$tenant' AND invoiceno = '$invoiceno' 
                AND invoiceyear = YEAR(CURDATE())) ORDER BY id";
        $stmt1 = $db->query($qry1);
        while($row_edt1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
            $surname = $row_edt1['id'];
            $to = $row_edt1['email'];
            $name = $row_edt1['surname']." ".$row_edt1['othername'];
            $msg .= "Dear $name<br><br>";
            $msg .= "This is to notify you that your invoice for $billname is now due.<br>";
            $msg .= "Amount Due: $amount<br><br>";
            $msg .= "Best Regards";
            send_email($msgorg,$to,$title,$msg);
            $qry2 = "INSERT INTO invoices (`date`,invoiceyear,invoicemonth,invoiceday,surname,invoiceno,billitemcode,amount,`invoicestatus`,tenant,user) 
            VALUES (CURDATE(),YEAR(CURDATE())),'Year','Year','$surname','$invoiceno','$billitemcode','$amount','Not Paid','$tenant','$user')";
            $stmt2 = $db->query($qry2);
        }
    } elseif($frequency == "Quarterly"){
        $qry0 = "SELECT * FROM billings_payperiod WHERE frequency = 'Quarterly' AND payperiod = MONTH(CURDATE())";
        $stmt0 = $db->query($qry0);
        $row_edt0 = $stmt0->fetch(PDO::FETCH_ASSOC);
        $invoiceday = $row_edt0['invoiceday'];
        if($invoiceday != ""){
            $qry1 = "SELECT * FROM residents WHERE tenant = '$tenant' AND id NOT IN 
            (SELECT surname FROM invoices WHERE tenant = '$tenant' AND invoiceno = '$invoiceno' 
                AND invoiceyear = YEAR(CURDATE()) AND invoicemonth = MONTH(CURDATE())) ORDER BY id DESC";
            $stmt1 = $db->query($qry1);
            while($row_edt1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
                $surname = $row_edt1['id'];
                $to = $row_edt1['email'];
                $name = $row_edt1['surname']." ".$row_edt1['othername'];
                $msg .= "Dear $name<br><br>";
                $msg .= "This is to notify you that your invoice for $billname is now due.<br>";
                $msg .= "Amount Due: $amount<br><br>";
                $msg .= "Best Regards";
                send_email($msgorg,$to,$title,$msg);
                $qry2 = "INSERT INTO invoices (`date`,invoiceyear,invoicemonth,invoiceday,surname,invoiceno,billitemcode,amount,`invoicestatus`,tenant,user) 
                VALUES (CURDATE(),YEAR(CURDATE())),MONTH(CURDATE()),'Quarter','$surname','$invoiceno','$billitemcode','$amount','Not Paid','$tenant','$user')";
                $stmt2 = $db->query($qry2);
            }       
        }
    } elseif($frequency == "Monthly"){
        $qry0 = "SELECT * FROM billings_payperiod WHERE frequency = 'Monthly' AND payperiod = MONTH(CURDATE())";
        $stmt0 = $db->query($qry0);
        $row_edt0 = $stmt0->fetch(PDO::FETCH_ASSOC);
        $invoiceday = $row_edt0['invoiceday'];
        if($invoiceday != ""){
            $qry1 = "SELECT * FROM residents WHERE tenant = '$tenant' AND id NOT IN 
            (SELECT surname FROM invoices WHERE tenant = '$tenant' AND invoiceno = '$invoiceno' 
                AND invoiceyear = YEAR(CURDATE()) AND invoicemonth = MONTH(CURDATE())) ORDER BY id DESC";
            $stmt1 = $db->query($qry1);
            while($row_edt1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
                $surname = $row_edt1['id'];
                $to = $row_edt1['email'];
                $name = $row_edt1['surname']." ".$row_edt1['othername'];
                $msg .= "Dear $name<br><br>";
                $msg .= "This is to notify you that your invoice for $billname is now due.<br>";
                $msg .= "Amount Due: $amount<br><br>";
                $msg .= "Best Regards";
                send_email($msgorg,$to,$title,$msg);
                $qry2 = "INSERT INTO invoices (`date`,invoiceyear,invoicemonth,invoiceday,surname,invoiceno,billitemcode,amount,`invoicestatus`,tenant,user) 
                VALUES (CURDATE(),YEAR(CURDATE())),MONTH(CURDATE()),'Month','$surname','$invoiceno','$billitemcode','$amount','Not Paid','$tenant','$user')";
                $stmt2 = $db->query($qry2);
               
            }       
        }
    } elseif($frequency == "Daily"){
        $qry0 = "SELECT * FROM billings_payperiod WHERE frequency = 'Daily' AND payperiod = DAYOFYEAR(CURDATE())";
        $stmt0 = $db->query($qry0);
        $row_edt0 = $stmt0->fetch(PDO::FETCH_ASSOC);
        $invoiceday = $row_edt0['invoiceday'];
        if($invoiceday != ""){
            $qry1 = "SELECT * FROM residents WHERE tenant = '$tenant' AND id NOT IN 
            (SELECT surname FROM invoices WHERE tenant = '$tenant' AND invoiceno = '$invoiceno' 
                AND invoiceyear = YEAR(CURDATE()) AND invoicemonth = MONTH(CURDATE()) AND invoiceday = DAYOFYEAR(CURDATE())) ORDER BY id DESC";
            $stmt1 = $db->query($qry1);
            while($row_edt1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
                $surname = $row_edt1['id'];
                $to = $row_edt1['email'];
                $name = $row_edt1['surname']." ".$row_edt1['othername'];
                $msg .= "Dear $name<br><br>";
                $msg .= "This is to notify you that your invoice for $billname is now due.<br>";
                $msg .= "Amount Due: $amount<br><br>";
                $msg .= "Best Regards";
                send_email($msgorg,$to,$title,$msg);
                $qry2 = "INSERT INTO invoices (`date`,invoiceyear,invoicemonth,invoiceday,surname,invoiceno,billitemcode,amount,`invoicestatus`,tenant,user) 
                VALUES (CURDATE(),YEAR(CURDATE())),MONTH(CURDATE()),DAYOFYEAR(CURDATE()),'$surname','$invoiceno','$billitemcode','$amount','Not Paid','$tenant','$user')";
                $stmt2 = $db->query($qry2);
            }       
        }
    }
}
?>